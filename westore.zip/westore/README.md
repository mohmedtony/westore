# wep store
#### Video Demo:  https://youtu.be/ZWUrzzUtj0c
## Description:
My final project is a wep store Application  
A simple web app 

------------------------------------------------------------------------------
## Prerequsites
- Make sure you have python installed and you use it to run this program.
- You have to make sure you have Flask installed. If not you can use pip or your favourite package manager to install it.
- ``pip install flask``  

------------------------------------------------------------------------------
## How to run
- you can visit the link after that you can enter wepsite 
then you can choose your product

------------------------------------------------------------------------------
## Files
- ``index.html`` it handles requests and respondes
- ``/main.js`` it's reqponsible for solving the game
- ``/static/`` it contains all styles and js files of the page
- ``/templates/`` it contains all HTML files of the page  

------------------------------------------------------------------------------  

------------------------------------------------------------------------------

------------------------------------------------------------------------------
## About CS50
CS50 is a openware course from Havard University and taught by David J. Malan

Introduction to the intellectual enterprises of computer science and the art of programming. This course teaches students how to think algorithmically and solve problems efficiently. Topics include abstraction, algorithms, data structures, encapsulation, resource management, security, and software engineering. Languages include C, Python, and SQL plus students’ choice of: HTML, CSS, and JavaScript (for web development).

Thank you for all CS50.